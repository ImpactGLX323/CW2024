package com.example.demo;

public class LevelOne extends LevelParent {

    private static final String BACKGROUND_IMAGE_NAME = "/com/example/demo/images/background1.jpg";
    private static final String NEXT_LEVEL = "com.example.demo.LevelTwo";
    private static final int TOTAL_ENEMIES = 5;
    private static final int KILLS_TO_ADVANCE = 10;
    private static final double ENEMY_SPAWN_PROBABILITY = 0.20;
    private static final int PLAYER_INITIAL_HEALTH = 5;

    public LevelOne(double screenHeight, double screenWidth) {
        super(BACKGROUND_IMAGE_NAME, screenHeight, screenWidth, PLAYER_INITIAL_HEALTH);
    }

    @Override
    protected void initializeFriendlyUnits() {
        System.out.println("Initializing friendly units for LevelOne...");
        addUserToRootSafely();
    }

    @Override
    protected void checkIfGameOver() {
        if (isUserDestroyed()) {
            loseGame();
        } else if (hasUserReachedKillTarget()) {
            goToNextLevel(NEXT_LEVEL);
        }
    }

    @Override
    protected void spawnEnemyUnits() {
        while (getCurrentEnemyCount() < TOTAL_ENEMIES) {
            if (Math.random() < ENEMY_SPAWN_PROBABILITY) {
                double newEnemyYPosition = Math.random() * getEnemyMaximumYPosition();
                spawnEnemy(new EnemyPlane(getScreenWidth(), newEnemyYPosition));
            }
        }
    }

    @Override
    protected LevelView createLevelView() {
        System.out.println("Creating LevelView for LevelOne...");
        return new LevelView(getRoot(), PLAYER_INITIAL_HEALTH);
    }

    private boolean hasUserReachedKillTarget() {
        return getUser().getNumberOfKills() >= KILLS_TO_ADVANCE;
    }

    // Safely transition to the next level
    private void goToNextLevel(String nextLevel) {
        try {
            System.out.println("Transitioning to next level: " + nextLevel);
            stopGame();
            getRoot().getChildren().clear();

            Class<?> levelClass = Class.forName(nextLevel);
            LevelParent nextLevelInstance = (LevelParent) levelClass.getConstructor(double.class, double.class)
                    .newInstance(getScreenHeight(), getScreenWidth());
            nextLevelInstance.startGame();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void addUserToRootSafely() {
        if (!getRoot().getChildren().contains(getUser())) {
            addUserToRoot();
        }
    }
}
