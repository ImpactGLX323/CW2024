package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

public abstract class LevelParent {

    private static final double SCREEN_HEIGHT_ADJUSTMENT = 150;
    private static final int GAME_UPDATE_INTERVAL = 50;

    private final double screenHeight;
    private final double screenWidth;
    private final double enemyMaxYPosition;

    private final Group root;
    private final Scene scene;
    private final Timeline gameLoop;
    private final UserPlane user;
    private final ImageView background;

    private final List<ActiveActorDestructible> enemyUnits = new ArrayList<>();
    protected LevelView levelView;

    public LevelParent(String backgroundImageName, double screenHeight, double screenWidth, int playerHealth) {
        this.screenHeight = screenHeight;
        this.screenWidth = screenWidth;
        this.enemyMaxYPosition = screenHeight - SCREEN_HEIGHT_ADJUSTMENT;

        this.root = new Group();
        this.scene = new Scene(root, screenWidth, screenHeight);
        this.user = new UserPlane(playerHealth);
        this.background = new ImageView(new Image(getClass().getResource(backgroundImageName).toExternalForm()));
        this.gameLoop = createGameLoop();

        initializeSceneElements();
    }

    protected abstract void initializeFriendlyUnits();

    protected abstract void checkIfGameOver();

    protected abstract void spawnEnemyUnits();

    protected abstract LevelView createLevelView();

    public Scene initializeScene() {
        root.getChildren().add(background);
        return scene;
    }

    public void startGame() {
        gameLoop.play();
    }

    protected boolean isUserDestroyed() {
        return user.isDestroyed();
    }

    protected int getCurrentEnemyCount() {
        return enemyUnits.size();
    }

    protected double getEnemyMaximumYPosition() {
        return enemyMaxYPosition;
    }

    protected void spawnEnemy(ActiveActorDestructible enemy) {
        enemyUnits.add(enemy);
        root.getChildren().add(enemy);
    }

    private Timeline createGameLoop() {
        Timeline timeline = new Timeline();
        KeyFrame frame = new KeyFrame(Duration.millis(GAME_UPDATE_INTERVAL), e -> updateGame());
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.getKeyFrames().add(frame);
        return timeline;
    }

    private void initializeSceneElements() {
        initializeBackground();
        root.getChildren().add(user);
        levelView = createLevelView(); // Ensure levelView is initialized first
        initializeFriendlyUnits();     // Call this after levelView is initialized
    }

    private void initializeBackground() {
        background.setFitHeight(screenHeight);
        background.setFitWidth(screenWidth);
    }

    private void updateGame() {
        spawnEnemyUnits();
        checkIfGameOver();
    }

    protected Group getRoot() {
        return root;
    }

    protected void addUserToRoot() {
        root.getChildren().add(user);
    }

    protected void loseGame() {
        stopGame();
        levelView.showGameOverImage();
    }

    protected void winGame() {
        stopGame();
        levelView.showWinImage();
    }

    protected void stopGame() {
        gameLoop.stop();
    }

    protected double getScreenWidth() {
        return screenWidth;
    }

    protected UserPlane getUser() {
        return user;
    }

    public double getScreenHeight() {
        return screenHeight;
    }
}
