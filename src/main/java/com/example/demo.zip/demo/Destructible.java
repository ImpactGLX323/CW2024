package com.example.demo;

public interface Destructible {

	void takeDamage();

	void destroy();
	
}
