package com.example.demo;

public class LevelTwo extends LevelParent {

    private static final String BACKGROUND_IMAGE_NAME = "/com/example/demo/images/background2.jpg";
    private static final int PLAYER_INITIAL_HEALTH = 5;
    private final Boss boss;
    private LevelViewLevelTwo levelView;

    public LevelTwo(double screenHeight, double screenWidth) {
        super(BACKGROUND_IMAGE_NAME, screenHeight, screenWidth, PLAYER_INITIAL_HEALTH);
        this.boss = new Boss();
    }

    @Override
    protected void initializeFriendlyUnits() {
        System.out.println("Initializing friendly units for LevelTwo...");
        addUserToRootSafely();
    }

    @Override
    protected void checkIfGameOver() {
        if (isUserDestroyed()) {
            loseGame();
        } else if (boss.isDestroyed()) {
            winGame();
        }
    }

    @Override
    protected void spawnEnemyUnits() {
        if (getCurrentEnemyCount() == 0) {
            spawnEnemy(boss);
        }
    }

    @Override
    protected LevelView createLevelView() {
        System.out.println("Creating LevelView for LevelTwo...");
        levelView = new LevelViewLevelTwo(getRoot(), PLAYER_INITIAL_HEALTH);
        return levelView;
    }

    private void addUserToRootSafely() {
        if (!getRoot().getChildren().contains(getUser())) {
            addUserToRoot();
        }
    }
}
